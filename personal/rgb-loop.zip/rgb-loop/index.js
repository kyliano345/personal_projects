const canvas = document.querySelector('canvas');
const c = canvas.getContext('2d');
canvas.width = innerWidth;
canvas.height = innerHeight;

var r = 255;
var g = 0;
var b = 0;
colorselect = true;
colorscreen = true;

/*function color_selection() {

    if (colorselect) {
        colorselect = false;
        while (true) {
            if (g <= 255) {
                r--
                g++
                break;
            } else if (b <= 255) {
                g--
                b++
                break;
            } else {
                b--
                r++
                break;
            }
        }
        setTimeout(() => {
            colorselect = true;
        }, 150);
    }
}*/
function animate() {
    color_onscreen()
    requestAnimationFrame(animate)
}

    


i = 0;
function color_onscreen() {

    while (colorscreen) {
      
    
         colorscreen = false;
         c.fillStyle = `hsl(${0 + i}, 100%, 50%)`;
         c.fillRect(0, 0, canvas.width, canvas.height)
        
         i++
           setTimeout(() => {
            colorscreen = true;
        }, 10);
    }
}
   


animate()

